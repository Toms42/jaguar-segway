Segstick PCB Readme

File List:

segstick.GTL Top Layer
segstick.GBL Bottom Layer
segstick.GTS Top Soldermask
segstick.GBS Bottom Soldermask
segstick.GTO Top Silkscreen
segstick.GBO Bottom Silkscreen
segstick.GKO Board Outline
segstick.XLN Drills
segstick.dri Tool size report