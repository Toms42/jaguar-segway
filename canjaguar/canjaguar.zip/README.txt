For help on using this library consult the wiki at 
https://sourceforge.net/p/ardurio/wiki/browse_pages/